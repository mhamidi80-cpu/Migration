
module "vpc" {
  source = "../../modules/vpc"
  cidr   = "172.16.0.0/16"
}
