
variable "ami" {}
