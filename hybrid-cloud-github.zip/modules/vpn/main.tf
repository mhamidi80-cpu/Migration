
resource "aws_vpn_gateway" "this" {
  vpc_id = var.vpc_id
}
