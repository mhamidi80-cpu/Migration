
resource "aws_subnet" "public" {
  vpc_id = var.vpc_id
  cidr_block = var.public_subnet
}
