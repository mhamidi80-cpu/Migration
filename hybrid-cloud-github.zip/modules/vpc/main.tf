
resource "aws_vpc" "this" {
  cidr_block = var.cidr
  enable_dns_hostnames = true
}
