# Hybrid Cloud Architecture (AWS + On-Prem)

## Overview
This project demonstrates a production-grade hybrid cloud architecture using AWS and on-premises integration.

## Features
- Modular Terraform (VPC, Subnets, ALB, EC2, RDS, VPN)
- Site-to-Site VPN with BGP
- Multi-AZ / scalable architecture
- Security-first (Zero Trust)

## Structure
- modules/
- environments/
- global/

## Usage
cd environments/prod
terraform init
terraform apply
